﻿using Number.Base;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Text.RegularExpressions;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace Number
{
    /// <summary>
    /// Логика взаимодействия для AddEmployeeWindow.xaml
    /// </summary>
    public partial class AddEmployeeWindow : Window
    {
        private Entities _entities;

        public AddEmployeeWindow(Entities entities)
        {
            InitializeComponent();
            _entities = entities;
        }

        private void ValidateLettersOnly(object sender, TextCompositionEventArgs e)
        {
            // Регулярное выражение для русских букв
            if (!Regex.IsMatch(e.Text, @"^[а-яА-Я]+$"))
            {
                e.Handled = true; // Блокируем ввод недопустимых символов
            }
        }

        private void ValidateDigitsOnly(object sender, TextCompositionEventArgs e)
        {
            // Регулярное выражение для цифр
            if (!Regex.IsMatch(e.Text, @"^[0-9]+$"))
            {
                e.Handled = true; // Блокируем ввод недопустимых символов
            }
        }

        private void ValidateTextBoxContent(TextBox textBox, Func<string, bool> validationRule)
        {
            if (!validationRule(textBox.Text))
            {
                // Если текст не соответствует правилам, удаляем последний символ
                textBox.Text = textBox.Text.Substring
                    (0, Math.Max(0, textBox.Text.Length - 1));
                textBox.CaretIndex = textBox.Text.Length; // Перемещаем курсор в конец
            }
        }

        private void SurnameTextBox_TextChanged(object sender, TextChangedEventArgs e)
        {
            ValidateTextBoxContent(SurnameTextBox,
                text => Regex.IsMatch(text, @"^[а-яА-Я]*$"));
        }

        private void NameTextBox_TextChanged(object sender, TextChangedEventArgs e)
        {
            ValidateTextBoxContent(NameTextBox,
                text => Regex.IsMatch(text, @"^[а-яА-Я]*$"));
        }

        private void MiddlenameTextBox_TextChanged(object sender, TextChangedEventArgs e)
        {
            ValidateTextBoxContent(MiddlenameTextBox,
                text => Regex.IsMatch(text, @"^[а-яА-Я]*$"));
        }

        private void PhoneNumberTextBox_TextChanged(object sender, TextChangedEventArgs e)
        {
            ValidateTextBoxContent(PhoneNumberTextBox,
                text => Regex.IsMatch(text, @"^[0-9]*$"));
        }

        private void AddressTextBox_TextChanged(object sender, TextChangedEventArgs e)
        {
            ValidateTextBoxContent(AddressTextBox,
                text => Regex.IsMatch(text, @"^[а-яА-Я]*$"));
        }

        private void SaveButton_Click(object sender, RoutedEventArgs e)
        {
            // Проверка обязательных полей
            if (string.IsNullOrWhiteSpace(SurnameTextBox.Text) ||
                string.IsNullOrWhiteSpace(NameTextBox.Text) ||
                string.IsNullOrWhiteSpace(PhoneNumberTextBox.Text))
            {
                MessageBox.Show("Необходимо заполнить все обязательные поля.", "Ошибка", MessageBoxButton.OK, MessageBoxImage.Warning);
                return;
            }

            try
            {
                // Создание нового сотрудника
                var newEmployee = new Employee
                {
                    Surname = SurnameTextBox.Text,
                    Name = NameTextBox.Text,
                    Middlename = MiddlenameTextBox.Text,
                    PhoneNumber = PhoneNumberTextBox.Text,
                    Post = PostTextBox.Text,
                    Adress = AddressTextBox.Text
                };

                // Добавление в базу данных
                _entities.Employees.Add(newEmployee);
                _entities.SaveChanges();

                MessageBox.Show("Сотрудник успешно добавлен.", "Успех", MessageBoxButton.OK, MessageBoxImage.Information);

                // Закрытие окна
                DialogResult = true;
                Close();
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Ошибка при добавлении сотрудника: {ex.Message}", "Ошибка", MessageBoxButton.OK, MessageBoxImage.Error);
            }
        }
    }
}
