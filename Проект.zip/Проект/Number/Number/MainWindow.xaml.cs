﻿using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using Number.Base;

namespace Number
{
    /// <summary>
    /// Логика взаимодействия для MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        private Entities entities;

        public MainWindow()
        {
            InitializeComponent();
            entities = new Entities();
            LoadEmployees(); // Загрузка данных о сотрудниках при запуске
        }

        private void CategoryComboBox_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            if (CategoryComboBox.SelectedItem is ComboBoxItem selectedItem)
            {
                // Удаляем все предыдущие обработчики
                AddButton.Click -= AddEmployee_Click;
                AddButton.Click -= AddAuditorium_Click;
                AddButton.Click -= AddEquipment_Click;

                EditButton.Click -= EditEmployee_Click;
                EditButton.Click -= EditAuditorium_Click;
                EditButton.Click -= EditEquipment_Click;

                DeleteButton.Click -= DeleteEmployee_Click;
                DeleteButton.Click -= DeleteAuditorium_Click;
                DeleteButton.Click -= DeleteEquipment_Click;

                // Назначаем новые обработчики в зависимости от выбранной категории
                switch (selectedItem.Content.ToString())
                {
                    case "Сотрудники":
                        AddButton.Click += AddEmployee_Click;
                        EditButton.Click += EditEmployee_Click;
                        DeleteButton.Click += DeleteEmployee_Click;
                        LoadEmployees();
                        break;

                    case "Аудитории":
                        AddButton.Click += AddAuditorium_Click;
                        EditButton.Click += EditAuditorium_Click;
                        DeleteButton.Click += DeleteAuditorium_Click;
                        LoadAuditoriums();
                        break;

                    case "Оборудование":
                        AddButton.Click += AddEquipment_Click;
                        EditButton.Click += EditEquipment_Click;
                        DeleteButton.Click += DeleteEquipment_Click;
                        LoadEquipment();
                        break;
                }
            }
        }
        private void AddButton_Click(object sender, RoutedEventArgs e)
        {
            var selectedItem = CategoryComboBox.SelectedItem as ComboBoxItem;
            if (selectedItem == null) return;

            switch (selectedItem.Content.ToString())
            {
                case "Сотрудники":
                    var addEmployeeWindow = new AddEmployeeWindow(entities);
                    if (addEmployeeWindow.ShowDialog() == true)
                    {
                        LoadEmployees();
                    }
                    break;

                case "Аудитории":
                    var addAuditoriumWindow = new AddAuditoriumWindow(entities);
                    if (addAuditoriumWindow.ShowDialog() == true)
                    {
                        LoadAuditoriums();
                    }
                    break;

                case "Оборудование":
                    var addEquipmentWindow = new AddEquipmentWindow(entities);
                    if (addEquipmentWindow.ShowDialog() == true)
                    {
                        LoadEquipment();
                    }
                    break;
            }
        }


        // Добавление нового сотрудника
        private void AddEmployee_Click(object sender, RoutedEventArgs e)
        {
            var addEmployeeWindow = new AddEmployeeWindow(entities);
            if (addEmployeeWindow.ShowDialog() == true)
            {
                LoadEmployees(); // Обновляем список сотрудников
            }
        }

        private void AddAuditorium_Click(object sender, RoutedEventArgs e)
        {
            var addAuditoriumWindow = new AddAuditoriumWindow(entities);
            if (addAuditoriumWindow.ShowDialog() == true)
            {
                LoadAuditoriums(); // Обновляем список аудиторий
            }
        }

        private void AddEquipment_Click(object sender, RoutedEventArgs e)
        {
            var addEquipmentWindow = new AddEquipmentWindow(entities);
            if (addEquipmentWindow.ShowDialog() == true)
            {
                LoadEquipment(); // Обновляем список оборудования
            }
        }

        // Редактирование сотрудника
        private void EditEmployee_Click(object sender, RoutedEventArgs e)
        {
            if (MainListBox.SelectedItem is EmployeeViewModel selectedEmployee)
            {
                var editEmployeeWindow = new EditEmployeeWindow
                    (entities, selectedEmployee.EmployeeID);
                if (editEmployeeWindow.ShowDialog() == true)
                {
                    LoadEmployees(); // Обновляем список сотрудников
                }
            }
            else
            {
                MessageBox.Show("Выберите сотрудника для редактирования.", 
                    "Информация", MessageBoxButton.OK, 
                    MessageBoxImage.Information);
            }
        }

        private void DeleteEmployee_Click(object sender, RoutedEventArgs e)
        {
            if (MainListBox.SelectedItem is EmployeeViewModel selectedEmployee)
            {
                if (MessageBox.Show("Вы уверены, что хотите удалить сотрудника?", 
                    "Подтверждение", MessageBoxButton.YesNo, 
                    MessageBoxImage.Warning) == MessageBoxResult.Yes)
                {
                    try
                    {
                        var employeeToDelete = entities.Employees.FirstOrDefault
                            (emp => emp.EmployeeID == selectedEmployee.EmployeeID);
                        if (employeeToDelete != null)
                        {
                            entities.Employees.Remove(employeeToDelete);
                            entities.SaveChanges();
                            LoadEmployees(); // Обновляем список сотрудников
                        }
                    }
                    catch (Exception ex)
                    {
                        MessageBox.Show($"Ошибка при удалении сотрудника: {ex.Message}", 
                            "Ошибка", MessageBoxButton.OK, MessageBoxImage.Error);
                    }
                }
            }
            else
            {
                MessageBox.Show("Выберите сотрудника для удаления.", 
                    "Информация", MessageBoxButton.OK, MessageBoxImage.Information);
            }
        }


        // Метод для загрузки данных об аудиториях
        private void LoadAuditoriums()
        {
            try
            {
                var auditoriums = entities.LectureHalls.ToList();

                // Преобразуем записи в список AuditoriumViewModel
                var auditoriumViewModels = auditoriums.
                    Select(a => new AuditoriumViewModel(a)).ToList();

                // Присваиваем список ListBox'у
                MainListBox.ItemsSource = auditoriumViewModels;
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Ошибка загрузки данных: {ex.Message}", 
                    "Ошибка", MessageBoxButton.OK, MessageBoxImage.Error);
            }
        }

        // Редактирование аудитории
        private void EditAuditorium_Click(object sender, RoutedEventArgs e)
        {
            if (MainListBox.SelectedItem is AuditoriumViewModel selectedAuditorium)
            {
                var editAuditoriumWindow = new EditAuditoriumWindow
                    (entities, selectedAuditorium.LectureHallID);
                if (editAuditoriumWindow.ShowDialog() == true)
                {
                    LoadAuditoriums(); // Обновляем список аудиторий
                }
            }
            else
            {
                MessageBox.Show("Выберите аудиторию для редактирования.", 
                    "Информация", MessageBoxButton.OK, MessageBoxImage.Information);
            }
        }

        // Удаление аудитории
        private void DeleteAuditorium_Click(object sender, RoutedEventArgs e)
        {
            if (MainListBox.SelectedItem is AuditoriumViewModel selectedAuditorium)
            {
                if (MessageBox.Show("Вы уверены, что хотите удалить аудиторию?", 
                    "Подтверждение", MessageBoxButton.YesNo, 
                    MessageBoxImage.Warning) == MessageBoxResult.Yes)
                {
                    try
                    {
                        var auditoriumToDelete = entities.LectureHalls
                            .FirstOrDefault(a => a.LectureHallID 
                            == selectedAuditorium.LectureHallID);
                        if (auditoriumToDelete != null)
                        {
                            entities.LectureHalls.Remove(auditoriumToDelete);
                            entities.SaveChanges();
                            LoadAuditoriums(); // Обновляем список аудиторий
                        }
                    }
                    catch (Exception ex)
                    {
                        MessageBox.Show($"Ошибка при удалении аудитории: {ex.Message}", 
                            "Ошибка", MessageBoxButton.OK, MessageBoxImage.Error);
                    }
                }
            }
            else
            {
                MessageBox.Show("Выберите аудиторию для удаления.", 
                    "Информация", MessageBoxButton.OK, MessageBoxImage.Information);
            }
        }

        // Метод для загрузки данных об оборудовании
        private void LoadEquipment()
        {
            try
            {
                var equipment = entities.Equipments.ToList();

                // Преобразуем записи в список EquipmentViewModel
                var equipmentViewModels = equipment.Select(eq => new 
                EquipmentViewModel(eq)).ToList();

                // Присваиваем список ListBox'у
                MainListBox.ItemsSource = equipmentViewModels;
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Ошибка загрузки данных: {ex.Message}", 
                    "Ошибка", MessageBoxButton.OK, MessageBoxImage.Error);
            }
        }

        // Редактирование оборудования
        private void EditEquipment_Click(object sender, RoutedEventArgs e)
        {
            if (MainListBox.SelectedItem is EquipmentViewModel selectedEquipment)
            {
                var editEquipmentWindow = new EditEquipmentWindow(entities, 
                    selectedEquipment.EquipmentID);
                if (editEquipmentWindow.ShowDialog() == true)
                {
                    LoadEquipment(); // Обновляем список оборудования
                }
            }
            else
            {
                MessageBox.Show("Выберите оборудование для редактирования.", "И" +
                    "нформация", MessageBoxButton.OK, MessageBoxImage.Information);
            }
        }

        private void DeleteEquipment_Click(object sender, RoutedEventArgs e)
        {
            if (MainListBox.SelectedItem is EquipmentViewModel selectedEquipment)
            {
                if (MessageBox.Show("Вы уверены, что хотите удалить оборудование?", 
                    "Подтверждение", MessageBoxButton.YesNo, MessageBoxImage.
                    Warning) == MessageBoxResult.Yes)
                {
                    try
                    {
                        var equipmentToDelete = entities.Equipments.
                            FirstOrDefault(eq => eq.EquipmentID == 
                            selectedEquipment.EquipmentID);
                        if (equipmentToDelete != null)
                        {
                            entities.Equipments.Remove(equipmentToDelete);
                            entities.SaveChanges();
                            LoadEquipment(); // Обновляем список оборудования
                        }
                    }
                    catch (Exception ex)
                    {
                        MessageBox.Show($"Ошибка при удалении оборудования: " +
                            $"{ex.Message}", "Ошибка", MessageBoxButton.OK, 
                            MessageBoxImage.Error);
                    }
                }
            }
            else
            {
                MessageBox.Show("Выберите оборудование для удаления.", 
                    "Информация", MessageBoxButton.OK, MessageBoxImage.Information);
            }
        }

        // Метод для загрузки данных о сотрудниках
        private void LoadEmployees()
        {
            try
            {
                var employees = entities.Employees.ToList();
                MainListBox.ItemsSource = employees
                    .Select(e => new EmployeeViewModel(e)).ToList();
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Ошибка загрузки данных: {ex.Message}", 
                    "Ошибка", MessageBoxButton.OK, MessageBoxImage.Error);
            }
        }

        private void EditButton_Click(object sender, RoutedEventArgs e)
        {

        }

        private void DeleteButton_Click(object sender, RoutedEventArgs e)
        {

        }
    }

    public class EmployeeViewModel
    {
        public int EmployeeID { get; set; }
        public string FullName { get; set; }
        public string PhoneNumber { get; set; }
        public string Post { get; set; }
        public string Adress { get; set; }

        public EmployeeViewModel(Employee employee)
        {
            EmployeeID = employee.EmployeeID;
            FullName = $"{employee.Surname} " +
                $"{employee.Name} " +
                $"{employee.Middlename}";
            PhoneNumber = employee.PhoneNumber;
            Post = employee.Post;
            Adress = employee.Adress;
        }
    }

    public class AuditoriumViewModel
    {
        public int LectureHallID { get; set; }
        public string LectureHallNumber { get; set; }
        public string LecturedHallName { get; set; }
        public string ResponsibleFullName { get; set; }

        public AuditoriumViewModel(LectureHall auditorium)
        {
            LectureHallID = auditorium.LectureHallID;
            LectureHallNumber = auditorium.LectureHallNumber;
            LecturedHallName = auditorium.LecturedHallName;
            ResponsibleFullName = $"{auditorium.Employee?.Surname} " +
                $"{auditorium.Employee?.Name} " +
                $"{auditorium.Employee?.Middlename}";
        }
    }

    public class EquipmentViewModel
    {
        public int EquipmentID { get; set; }
        public string InventoryNumber { get; set; }
        public string FactoryNumber { get; set; }
        public string EquipmentName { get; set; }
        public DateTime ArrivalDate { get; set; }
        public string LectureHallName { get; set; }

        public EquipmentViewModel(Equipment equipment)
        {
            EquipmentID = equipment.EquipmentID;
            InventoryNumber = equipment.InventoryNumber;
            FactoryNumber = equipment.FactoryNumber;
            EquipmentName = equipment.EquipmentName;
            LectureHallName = equipment.LectureHall?.LecturedHallName;
        }
    }
}