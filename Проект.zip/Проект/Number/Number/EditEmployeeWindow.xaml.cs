﻿using Number.Base;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace Number
{
    /// <summary>
    /// Логика взаимодействия для EditEmployeeWindow.xaml
    /// </summary>
    public partial class EditEmployeeWindow : Window
    {
        private Entities _entities;
        private int _employeeId;

        public EditEmployeeWindow(Entities entities, int employeeId)
        {
            InitializeComponent();
            _entities = entities;
            _employeeId = employeeId;

            LoadEmployeeData();
        }

        // Метод для загрузки данных сотрудника
        private void LoadEmployeeData()
        {
            try
            {
                var employee = _entities.Employees.FirstOrDefault(e => e.EmployeeID == _employeeId);
                if (employee != null)
                {
                    SurnameTextBox.Text = employee.Surname;
                    NameTextBox.Text = employee.Name;
                    MiddlenameTextBox.Text = employee.Middlename;
                    PhoneNumberTextBox.Text = employee.PhoneNumber;
                    PostTextBox.Text = employee.Post;
                    AddressTextBox.Text = employee.Adress;
                }
                else
                {
                    MessageBox.Show("Сотрудник не найден.", "Ошибка", MessageBoxButton.OK, MessageBoxImage.Error);
                    Close();
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Ошибка при загрузке данных сотрудника: {ex.Message}", "Ошибка", MessageBoxButton.OK, MessageBoxImage.Error);
            }
        }

        // Метод для сохранения изменений
        private void SaveButton_Click(object sender, RoutedEventArgs e)
        {
            // Проверка обязательных полей
            if (string.IsNullOrWhiteSpace(SurnameTextBox.Text) ||
                string.IsNullOrWhiteSpace(NameTextBox.Text) ||
                string.IsNullOrWhiteSpace(PhoneNumberTextBox.Text))
            {
                MessageBox.Show("Необходимо заполнить все обязательные поля.", "Ошибка", MessageBoxButton.OK, MessageBoxImage.Warning);
                return;
            }

            try
            {
                // Переименовываем параметр лямбда-выражения с "e" на "emp"
                var employee = _entities.Employees.FirstOrDefault(emp => emp.EmployeeID == _employeeId);
                if (employee != null)
                {
                    // Обновление данных сотрудника
                    employee.Surname = SurnameTextBox.Text;
                    employee.Name = NameTextBox.Text;
                    employee.Middlename = MiddlenameTextBox.Text;
                    employee.PhoneNumber = PhoneNumberTextBox.Text;
                    employee.Post = PostTextBox.Text;
                    employee.Adress = AddressTextBox.Text;

                    _entities.SaveChanges();

                    MessageBox.Show("Данные сотрудника успешно обновлены.", "Успех", MessageBoxButton.OK, MessageBoxImage.Information);

                    // Закрытие окна
                    DialogResult = true;
                    Close();
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Ошибка при обновлении данных сотрудника: {ex.Message}", "Ошибка", MessageBoxButton.OK, MessageBoxImage.Error);
            }
        }
    }
}
