﻿using Number.Base;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Text.RegularExpressions;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;
using Number.Base;

namespace Number
{
    /// <summary>
    /// Логика взаимодействия для AddAuditoriumWindow.xaml
    /// </summary>
    public partial class AddAuditoriumWindow : Window
    {
        private Entities _entities;

        public AddAuditoriumWindow(Entities entities)
        {
            InitializeComponent();
            _entities = entities;

            // Загрузка сотрудников в выпадающий список
            var employees = _entities.Employees.ToList(); // Сначала загрузите все записи
            ResponsibleComboBox.ItemsSource = employees
                .Where(e => !string.IsNullOrEmpty(e.Surname) && !string.IsNullOrEmpty(e.Name))
                .Select(e => new EmployeeViewModel(e))
                .ToList();
        }

        private void SaveButton_Click(object sender, RoutedEventArgs e)
        {
            // Проверка обязательных полей
            if (string.IsNullOrWhiteSpace(NameTextBox.Text))
            {
                MessageBox.Show("Необходимо указать название аудитории.", "Ошибка", MessageBoxButton.OK, MessageBoxImage.Warning);
                return;
            }

            try
            {
                // Создание новой аудитории
                var newAuditorium = new LectureHall
                {
                    LecturedHallName = NameTextBox.Text,
                    LectureHallNumber = NumberTextBox.Text,
                    EmployeeID = (ResponsibleComboBox.SelectedItem as Employee)?.EmployeeID
                };

                // Добавление в базу данных
                _entities.LectureHalls.Add(newAuditorium);
                _entities.SaveChanges();

                MessageBox.Show("Аудитория успешно добавлена.", "Успех", MessageBoxButton.OK, MessageBoxImage.Information);

                // Закрытие окна
                DialogResult = true;
                Close();
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Ошибка при добавлении аудитории: {ex.Message}", "Ошибка", MessageBoxButton.OK, MessageBoxImage.Error);
            }
        }

        private void ValidateRussianLetters(object sender, TextCompositionEventArgs e)
        {
            // Разрешаем только русские буквы
            if (!Regex.IsMatch(e.Text, @"^[а-яА-Я]+$"))
            {
                e.Handled = true; // Блокируем ввод недопустимых символов
            }
        }

        private void FormatNumberTextBox(object sender, TextChangedEventArgs e)
        {
            if (sender is TextBox textBox && !string.IsNullOrEmpty(textBox.Text))
            {
                // Преобразуем первую букву в заглавную
                textBox.Text = char.ToUpper(textBox.Text[0]) + textBox.Text.Substring(1);
                textBox.CaretIndex = textBox.Text.Length; // Перемещаем курсор в конец
            }
        }
        public class EmployeeViewModel
        {
            public int EmployeeID { get; set; }
            public string FullName { get; set; }

            public EmployeeViewModel(Employee employee)
            {
                EmployeeID = employee.EmployeeID;
                FullName = $"{employee.Surname} {employee.Name} {employee.Middlename}".Trim();
            }
        }
    }
}
