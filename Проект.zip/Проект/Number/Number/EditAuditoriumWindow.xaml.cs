﻿using Number.Base;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace Number
{
    /// <summary>
    /// Логика взаимодействия для EditAuditoriumWindow.xaml
    /// </summary>
    public partial class EditAuditoriumWindow : Window
    {
        private Entities _entities;
        private int _lectureHallId;

        public EditAuditoriumWindow(Entities entities, int lectureHallId)
        {
            InitializeComponent();
            _entities = entities;
            _lectureHallId = lectureHallId;

            LoadAuditoriumData();
        }

        // Метод для загрузки данных аудитории
        private void LoadAuditoriumData()
        {
            try
            {
                var auditorium = _entities.LectureHalls.FirstOrDefault(a => a.LectureHallID == _lectureHallId);
                if (auditorium != null)
                {
                    NameTextBox.Text = auditorium.LecturedHallName;
                    NumberTextBox.Text = auditorium.LectureHallNumber;

                    // Загрузка сотрудников в выпадающий список
                    ResponsibleComboBox.ItemsSource = _entities.Employees.ToList();
                    ResponsibleComboBox.SelectedItem = _entities.Employees.FirstOrDefault(e => e.EmployeeID == auditorium.EmployeeID);
                }
                else
                {
                    MessageBox.Show("Аудитория не найдена.", "Ошибка", MessageBoxButton.OK, MessageBoxImage.Error);
                    Close();
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Ошибка при загрузке данных аудитории: {ex.Message}", "Ошибка", MessageBoxButton.OK, MessageBoxImage.Error);
            }
        }

        // Метод для сохранения изменений
        private void SaveButton_Click(object sender, RoutedEventArgs e)
        {
            // Проверка обязательных полей
            if (string.IsNullOrWhiteSpace(NameTextBox.Text))
            {
                MessageBox.Show("Необходимо указать название аудитории.", "Ошибка", MessageBoxButton.OK, MessageBoxImage.Warning);
                return;
            }

            try
            {
                var auditorium = _entities.LectureHalls.FirstOrDefault(a => a.LectureHallID == _lectureHallId);
                if (auditorium != null)
                {
                    // Обновление данных аудитории
                    auditorium.LecturedHallName = NameTextBox.Text;
                    auditorium.LectureHallNumber = NumberTextBox.Text;
                    auditorium.EmployeeID = (ResponsibleComboBox.SelectedItem as Employee)?.EmployeeID;

                    _entities.SaveChanges();

                    MessageBox.Show("Данные аудитории успешно обновлены.", "Успех", MessageBoxButton.OK, MessageBoxImage.Information);

                    // Закрытие окна
                    DialogResult = true;
                    Close();
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Ошибка при обновлении данных аудитории: {ex.Message}", "Ошибка", MessageBoxButton.OK, MessageBoxImage.Error);
            }
        }
    }
}

