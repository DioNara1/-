﻿using Number.Base;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace Number
{
    /// <summary>
    /// Логика взаимодействия для EditEquipmentWindow.xaml
    /// </summary>
    public partial class EditEquipmentWindow : Window
    {
        private Entities _entities; // Контекст базы данных
        private int _equipmentId;  // Идентификатор редактируемого оборудования

        public EditEquipmentWindow(Entities entities, int equipmentId)
        {
            InitializeComponent();
            _entities = entities;
            _equipmentId = equipmentId;

            LoadEquipmentData(); // Загрузка данных оборудования
        }

        // Метод для загрузки данных оборудования
        private void LoadEquipmentData()
        {
            try
            {
                var equipment = _entities.Equipments.FirstOrDefault(e => e.EquipmentID == _equipmentId);
                if (equipment != null)
                {
                    // Заполнение полей данными
                    InventoryNumberTextBox.Text = equipment.InventoryNumber;
                    FactoryNumberTextBox.Text = equipment.FactoryNumber;
                    NameTextBox.Text = equipment.EquipmentName;
                    ArrivalDatePicker.SelectedDate = equipment.ArrivalDate;

                    // Загрузка аудиторий в выпадающий список
                    AuditoriumComboBox.ItemsSource = _entities.LectureHalls.ToList();
                    AuditoriumComboBox.SelectedItem = _entities.LectureHalls.FirstOrDefault(l => l.LectureHallID == equipment.LectureHallID);
                }
                else
                {
                    MessageBox.Show("Оборудование не найдено.", "Ошибка", MessageBoxButton.OK, MessageBoxImage.Error);
                    Close();
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Ошибка при загрузке данных оборудования: {ex.Message}", "Ошибка", MessageBoxButton.OK, MessageBoxImage.Error);
            }
        }

        // Метод для сохранения изменений
        private void SaveButton_Click(object sender, RoutedEventArgs e)
        {
            // Проверка обязательных полей
            if (string.IsNullOrWhiteSpace(InventoryNumberTextBox.Text) ||
                string.IsNullOrWhiteSpace(NameTextBox.Text) ||
                ArrivalDatePicker.SelectedDate == null)
            {
                MessageBox.Show("Необходимо заполнить все обязательные поля.", "Ошибка", MessageBoxButton.OK, MessageBoxImage.Warning);
                return;
            }

            try
            {
                var equipment = _entities.Equipments.FirstOrDefault(emp => emp.EquipmentID == _equipmentId);
                if (equipment != null)
                {
                    // Обновление данных оборудования
                    equipment.InventoryNumber = InventoryNumberTextBox.Text;
                    equipment.FactoryNumber = FactoryNumberTextBox.Text;
                    equipment.EquipmentName = NameTextBox.Text;
                    equipment.ArrivalDate = ArrivalDatePicker.SelectedDate.Value;
                    equipment.LectureHallID = (AuditoriumComboBox.SelectedItem as LectureHall)?.LectureHallID;

                    _entities.SaveChanges(); // Сохранение изменений в базе данных

                    MessageBox.Show("Данные оборудования успешно обновлены.", "Успех", MessageBoxButton.OK, MessageBoxImage.Information);

                    DialogResult = true; // Указываем, что изменения были сохранены
                    Close(); // Закрываем окно
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Ошибка при обновлении данных оборудования: {ex.Message}", "Ошибка", MessageBoxButton.OK, MessageBoxImage.Error);
            }
        }
    }
}