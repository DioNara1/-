﻿using Number.Base;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Text.RegularExpressions;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace Number
{
    /// <summary>
    /// Логика взаимодействия для AddEquipmentWindow.xaml
    /// </summary>
    public partial class AddEquipmentWindow : Window
    {
        private Entities _entities;

        public AddEquipmentWindow(Entities entities)
        {
            InitializeComponent();
            _entities = entities;

            // Загрузка аудиторий в выпадающий список
            AuditoriumComboBox.ItemsSource = _entities.LectureHalls.ToList();
        }

        private void SaveButton_Click(object sender, RoutedEventArgs e)
        {
            // Проверка обязательных полей
            if (string.IsNullOrWhiteSpace(InventoryNumberTextBox.Text) ||
                string.IsNullOrWhiteSpace(NameTextBox.Text) ||
                ArrivalDatePicker.SelectedDate == null)
            {
                MessageBox.Show("Необходимо заполнить все обязательные поля.", "Ошибка", MessageBoxButton.OK, MessageBoxImage.Warning);
                return;
            }

            try
            {
                // Создание нового оборудования
                var newEquipment = new Equipment
                {
                    InventoryNumber = InventoryNumberTextBox.Text,
                    FactoryNumber = FactoryNumberTextBox.Text,
                    EquipmentName = NameTextBox.Text,
                    ArrivalDate = ArrivalDatePicker.SelectedDate.Value,
                    LectureHallID = (AuditoriumComboBox.SelectedItem as LectureHall)?.LectureHallID
                };

                // Добавление в базу данных
                _entities.Equipments.Add(newEquipment);
                _entities.SaveChanges();

                MessageBox.Show("Оборудование успешно добавлено.", "Успех", MessageBoxButton.OK, MessageBoxImage.Information);

                // Закрытие окна
                DialogResult = true;
                Close();
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Ошибка при добавлении оборудования: {ex.Message}", "Ошибка", MessageBoxButton.OK, MessageBoxImage.Error);
            }
        }

        private void ValidateEnglishLettersAndDigits(object sender, TextCompositionEventArgs e)
        {
            // Разрешаем только английские буквы, цифры и пробелы
            if (!Regex.IsMatch(e.Text, @"^[a-zA-Z0-9 ]+$"))
            {
                e.Handled = true; // Блокируем ввод недопустимых символов
            }
        }

        private void ValidateRussianLettersOnly(object sender, TextCompositionEventArgs e)
        {
            // Разрешаем только русские буквы
            if (!Regex.IsMatch(e.Text, @"^[а-яА-Я]+$"))
            {
                e.Handled = true; // Блокируем ввод недопустимых символов
            }
        }

        private void ValidateTextBoxContent(TextBox textBox, Func<string, bool> validationRule)
        {
            if (!validationRule(textBox.Text))
            {
                // Если текст не соответствует правилам, удаляем последний символ
                textBox.Text = textBox.Text.Substring(0, Math.Max(0, textBox.Text.Length - 1));
                textBox.CaretIndex = textBox.Text.Length; // Перемещаем курсор в конец
            }
        }

        private void FormatTextBoxToTitleCase(object sender, TextChangedEventArgs e)
        {
            if (sender is TextBox textBox && !string.IsNullOrEmpty(textBox.Text))
            {
                // Преобразуем первую букву в заглавную
                textBox.Text = char.ToUpper(textBox.Text[0]) + textBox.Text.Substring(1);
                textBox.CaretIndex = textBox.Text.Length; // Перемещаем курсор в конец
            }
        }

        private void InventoryNumberTextBox_TextChanged(object sender, TextChangedEventArgs e)
        {
            ValidateTextBoxContent(InventoryNumberTextBox, text => Regex.IsMatch(text, @"^[a-zA-Z0-9 ]*$"));
        }

        private void FactoryNumberTextBox_TextChanged(object sender, TextChangedEventArgs e)
        {
            ValidateTextBoxContent(FactoryNumberTextBox, text => Regex.IsMatch(text, @"^[a-zA-Z0-9 ]*$"));
        }

        private void NameTextBox_TextChanged(object sender, TextChangedEventArgs e)
        {
            ValidateTextBoxContent(NameTextBox, text => Regex.IsMatch(text, @"^[а-яА-Я]*$"));
        }
    }
}